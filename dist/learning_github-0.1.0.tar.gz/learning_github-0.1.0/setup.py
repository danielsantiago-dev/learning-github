from setuptools import setup, find_packages

setup(
    name="learning-github",
    version="0.1.0",
    packages=find_packages(),
    description="A simple pip package",
    author="Daniel Santiago",
    author_email="daniel@dsantiago.com",
    url="https://github.com/danielsantiago-dev/learning-github"
)

#python setup.py bdist_wheel sdist
