def greeting(name):
    return "Hi " + name + ", this is my first pip package"
